import type { MetadataRoute } from "next";

const BASE = (process.env.NEXT_PUBLIC_SITE_URL || "https://www.alahedholding.com").replace(/\/$/, "");

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/en/admin", "/ar/admin", "/api/"] }],
    sitemap: `${BASE}/sitemap.xml`,
  };
}
